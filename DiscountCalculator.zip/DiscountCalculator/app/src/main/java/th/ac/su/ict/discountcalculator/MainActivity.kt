package th.ac.su.ict.discountcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Debug
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn = findViewById<Button>(R.id.btn)
        var box = findViewById<CheckBox>(R.id.box)
        var display = findViewById<TextView>(R.id.display)
        var tax = findViewById<EditText>(R.id.tax)
        var price = findViewById<EditText>(R.id.price)

        btn.setOnClickListener {
            var ta = tax.text.toString().toInt()
            var pr = price.text.toString().toInt()
            var discount = pr * ta/100.0;

            if(box.isChecked()){
                var vat = 7/100.0;
                var cal = pr.toFloat() - discount.toFloat();
                display.text = (cal + cal*vat ).toString();
            }else
                display.text = (pr - discount).toString();
        }



    }
}